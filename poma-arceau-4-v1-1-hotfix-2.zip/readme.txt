The original pack is published by coinc1234 on Discord, if you have paid to get it from a third-party, that means he violated my terms.
Redistributions of the original pack are fine if they aren't paid.
Usage on server resource pack is allowed.